<?php

require '../src/Json/Validator.php';

define('TEST_DIR', realpath(__DIR__));